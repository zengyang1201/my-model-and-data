# -*- coding: utf-8 -*-
"""
Created on Tue Jun 22 15:52:53 2021

@author: lenovo
"""
#1
import pandas as pd
# 读取excel文件，index_col=0，实现把第1列SKU设置为索引，后面就不用再写代码行：df = df.set_index(['SKU'])
df = pd.read_excel('Gsaveadesallcount.xlsx', sheet_name='Gsaveadesallcount', index_col=0)

# stack将数据的列旋转为行(自动剔除null)，延申一下：unstack将数据的行旋转为列
df = df.stack()
# stack列转行后出现层次化索引
print('stack列转行后数据形式：', '\n', df.head())
# reset_index还原索引，把层次化索引变为默认的整型索引，层次化索引被还原成普通列
df = df.reset_index()
# 设置数据列名
df.columns = ['Date', 'Time', 'Gsaveadesallcount']
print('\n最终dataframe形式：', '\n',  df)

df.to_csv('N1Gsaveadesallcount.csv')


#2
import pandas as pd
# 读取excel文件，index_col=0，实现把第1列SKU设置为索引，后面就不用再写代码行：df = df.set_index(['SKU'])
df = pd.read_excel('Gsaveadesdelaycount.xlsx', sheet_name='Gsaveadesdelaycount', index_col=0)

# stack将数据的列旋转为行(自动剔除null)，延申一下：unstack将数据的行旋转为列
df = df.stack()
# stack列转行后出现层次化索引
print('stack列转行后数据形式：', '\n', df.head())
# reset_index还原索引，把层次化索引变为默认的整型索引，层次化索引被还原成普通列
df = df.reset_index()
# 设置数据列名
df.columns = ['Date', 'Time', 'Gsaveadesdelaycount']
print('\n最终dataframe形式：', '\n',  df)

df.to_csv('N1Gsaveadesdelaycount.csv')


#3
import pandas as pd
# 读取excel文件，index_col=0，实现把第1列SKU设置为索引，后面就不用再写代码行：df = df.set_index(['SKU'])
df = pd.read_excel('Gsaveadesdelaytime.xlsx', sheet_name='Gsaveadesdelaytime', index_col=0)

# stack将数据的列旋转为行(自动剔除null)，延申一下：unstack将数据的行旋转为列
df = df.stack()
# stack列转行后出现层次化索引
print('stack列转行后数据形式：', '\n', df.head())
# reset_index还原索引，把层次化索引变为默认的整型索引，层次化索引被还原成普通列
df = df.reset_index()
# 设置数据列名
df.columns = ['Date', 'Time', 'Gsaveadesdelaytime']
print('\n最终dataframe形式：', '\n',  df)

df.to_csv('N1Gsaveadesdelaytime.csv')
