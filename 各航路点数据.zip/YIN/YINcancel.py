# -*- coding: utf-8 -*-
"""
Created on Tue Jun 22 18:57:58 2021

@author: lenovo
"""

#计算各航路点策略发布平均流控间隔
#预处理

import pandas as pd
import  datetime
import xlrd
import time
from datetime import datetime
import numpy as np
import xlsxwriter

def read_xlsx(path,sheetname):
    rbook = xlrd.open_workbook(path)
    sheet = rbook.sheet_by_name(sheetname)
    rows = sheet.nrows
    cols = sheet.ncols
    all_content = []
    for i in range(rows):
        row_content = []
        for j in range(cols):
            ctype = sheet.cell(i, j).ctype  # 表格的数据类型
            cell = sheet.cell_value(i, j)
            if ctype == 2 and cell % 1 == 0:  # 如果是整形
                cell = int(cell)
            elif ctype == 3:
                # 转成datetime对象
                date = datetime(*xlrd.xldate_as_tuple(cell, 0))
                data_temp = date.strftime('%Y/%d/%m %H')
                cell = int(time.mktime(time.strptime(data_temp, '%Y/%d/%m %H')))
            elif ctype == 4:
                cell = True if cell == 1 else False
            row_content.append(cell)
        all_content.append(row_content)
        #print ('[' + ','.join("'" + str(element) + "'" for element in row_content) + ']')
    return all_content



#读取数据
if __name__=='__main__':
    path1 = r'flow2018.xlsx'
    sheetname1 = r'flow2018'
    all_content_data = read_xlsx(path1, sheetname1)# 读取原始数据
    all_content_data = np.array(all_content_data)
    tips=np.delete(all_content_data,0,0)
    #Time_METAR=all_content_METAR[:,0]
    path2 = r'Ycancel1.xlsx'
    sheetname2 = r'Ycancel1'
    all_content_data1 = read_xlsx(path2, sheetname2)# 读取原始数据
    all_content_data1 = np.array(all_content_data1)
    ppp=np.delete(all_content_data1,0,0)
    path3 = r'Ycancel2.xlsx'
    sheetname3 = r'Ycancel2'
    all_content_data2 = read_xlsx(path3, sheetname3)# 读取原始数据
    all_content_data2 = np.array(all_content_data2)
    pppp=np.delete(all_content_data2,0,0)


#循环查询


for i in range(len(tips)):
    count=0
#    sum =0    
    for j in range(len(ppp)):
        if tips[i][0]==ppp[j][5]:
            count  = count+1
#            x = int(ppp[j][7])
#            sum = sum+x
            tips[i][1]=(count)
            
#            tips[i][3]=ppp[j][3]
            print (i,j)
#            print(tips[i][0])
#            print(ppp[j][5])
#            
#            count(j)
  #          print("tips[i][11]")
#            print (i,j,0)
#            tips[i][6]=2

print("end")
    
for i in range(len(tips)):
    count=0
#    sum =0    
    for j in range(len(pppp)):
        if tips[i][0]==pppp[j][5]:
            count  = count+1
#            x = int(pppp[j][7])
#            sum = sum+x
            tips[i][1]=(count)
            
#            tips[i][3]=ppp[j][3]
            print (i,j)
#            print(tips[i][0])
#            print(pppp[j][5])
            
#            count(j)
  #          print("tips[i][11]")
#            print (i,j,0)
#            tips[i][6]=2
print("end")
#end########################################